using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class Candy : MonoBehaviour
{
    
    public int row, col, targetX, targetY,prevRow,prevCol;
    Vector2 firstPos, secondPos, pos;
    float angle;
    
    public Vector3 worldPos;
    GameObject oppCandy;
    Board board;
    public bool isMatched;
    public int count = 3;
    // Start is called before the first frame update
    void Start()
    {
        board = FindObjectOfType<Board>();

    }

    // Update is called once per frame
    void Update()
    {
        targetX = col;
        targetY = row;
        if (Mathf.Abs(targetX - transform.position.x) > 0f)
        {
            Vector2 pos = new Vector2(targetX, transform.position.y);
            transform.position = Vector2.Lerp(transform.position, pos, .5f);
            if (this.gameObject != board.allCandies[col, row])
            {
                board.allCandies[col, row] = this.gameObject;
            }
        }
        if (Mathf.Abs(targetY - transform.position.y) > 0f)
        {
            Vector2 pos = new Vector2(transform.position.x, targetY);
            transform.position = Vector2.Lerp(transform.position, pos, .5f);
            if (this.gameObject != board.allCandies[col, row])
            {
                board.allCandies[col, row] = this.gameObject;
            }
        }
        findMatches();
        power();
        //board.destroyMatchCandies();
        //if(isMatched)
        //    Destroy(this.gameObject);
    }
    private void OnMouseDown()
    {
        firstPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        print(firstPos);
    }
    private void OnMouseUp()
    {
        secondPos =Camera.main.ScreenToWorldPoint(Input.mousePosition);
        print(secondPos);
        calculateAngle();
    }
    void calculateAngle()
    {
        Vector2 offset = new Vector2(secondPos.x-firstPos.x,secondPos.y-firstPos.y);
        angle = Mathf.Atan2 (offset.y,offset.x)* Mathf.Rad2Deg;

        //print(angle);
        MoveDirection();
    }
    void MoveDirection()
    {
        if (angle<=45f && angle >= -45f)
        {
            print("right");
            prevRow = row;
            prevCol = col;
            oppCandy = board.allCandies[col+1, row];
            oppCandy.GetComponent<Candy>().col -= 1;
            col += 1;
        }
        else if (angle<=135f && angle>=45f)
        {
            prevRow = row;
            prevCol = col;
            oppCandy = board.allCandies[col, row+1];
            oppCandy.GetComponent<Candy>().row -= 1;
            row += 1;
            print("UP");
        }
        else if (angle >= 135f || angle <= -135f)
        {
            prevRow = row;
            prevCol = col;
            print("left");
            oppCandy = board.allCandies[col-1, row];
            oppCandy.GetComponent<Candy>().col += 1;
            col -= 1;
        }
        else if (angle >= -135f && angle <= -45f)
        {
            prevRow = row;
            prevCol = col;
            print("down");
            oppCandy = board.allCandies[col, row - 1];
            oppCandy.GetComponent<Candy>().row += 1;
            row -= 1;
        }
        StartCoroutine(checkMatchesCo());
    }

    void findMatches()
    {
        if (col > 0 && col < board.cols - 1)
        {
            GameObject curCandy = board.allCandies[col, row];
            if (curCandy != null)
            {
                GameObject leftCandy = board.allCandies[col - 1, row];
                GameObject rightCandy = board.allCandies[col + 1, row];
                if (leftCandy != null && rightCandy != null)
                {
                    if (leftCandy.tag == curCandy.tag && rightCandy.tag == curCandy.tag)
                    {
                        isMatched = true;
                        leftCandy.GetComponent<Candy>().isMatched = true;
                        rightCandy.GetComponent<Candy>().isMatched = true;
                    }

                }
            }
        }
        if (row > 0 && row < board.rows - 1)
        {
            GameObject curCandy = board.allCandies[col, row];
            if (curCandy != null)
            {
                GameObject downCandy = board.allCandies[col, row-1];
                GameObject upCandy = board.allCandies[col, row+1];
                if (downCandy != null && upCandy != null)
                {
                    if (downCandy.tag == curCandy.tag && upCandy.tag == curCandy.tag)
                    {
                        isMatched = true;
                        downCandy.GetComponent<Candy>().isMatched = true;
                        upCandy.GetComponent<Candy>().isMatched = true;
                    }

                }
            }
        }

    }
    IEnumerator checkMatchesCo()
    {
        yield return new WaitForSeconds(0.5f);
        if (oppCandy!=null)
        {
            if (!isMatched && !oppCandy.GetComponent<Candy>().isMatched)
            {
                oppCandy.GetComponent <Candy>().row = row;
                oppCandy.GetComponent <Candy>().col = col;
                row = prevRow;
                col = prevCol;
                oppCandy = null;
            }
            else
            {
                board.destroyMatchCandies();
                oppCandy = null;
            }
        }
    }
    void power()
    {
        if(this.tag=="powerCandy" && row==0)
        {
            manager.inst.noOfpoewer =manager.inst.noOfpoewer -1;
            isMatched=true;
            board.destroyMatchCandies();
        }
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class powerCandy : MonoBehaviour
{
    public static powerCandy Instance;
    public int row , col ;
    Board b;
    // Start is called before the first frame update
    void Start()
    {
       
    }
    public void checkdown()
    {

    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
